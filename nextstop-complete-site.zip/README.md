
# NextStop

Sitio web corporativo para NextStop, empresa especializada en la expansión de marcas a través de Amazon y Walmart Marketplace en México, Estados Unidos, Canadá y Europa.

## Estructura

- `index.html` - Página principal
- `styles.css` - Estilos globales
